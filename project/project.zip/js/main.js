document.addEventListener("DOMContentLoaded", function () {
    const subMenu = document.getElementById("subMenu");
    const myBtn = document.getElementById("rateHistory");

    myBtn.addEventListener('click', function (event) {
        event.stopPropagation();
        subMenu.classList.toggle("active");
    });


   // window.addEventListener('click', function (event) {
       // if (!event.target.closest('#rateHistory')) {
       //     subMenu.style.display = 'none';
      //  }
  //  });

  const cardContainer = document.getElementById("cardContainer");
    const pickedCard = document.getElementById("cardPicked");
    const blueDeck = document.getElementById("blue_deck");

    for (let i = 1; i <= 15; i++) {
        const card = createCard(i);
        cardContainer.appendChild(card);
    }

   

    function createCard(cardNumber) {
        const card = document.createElement("div");
        card.className = "card";
        card.textContent = cardNumber;

        card.addEventListener('click', function () {
            const cards = cardContainer.getElementsByClassName('card');
            Array.from(cards).forEach(function (c) {
                c.classList.remove('selected');
            });

            card.classList.add('selected');

            pickedCard.classList.add("blue");
            blueDeck.classList.add("reveal");
        });

        return card;
    }

});